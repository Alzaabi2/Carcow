import React  from "react";
import { render } from "react-dom";

async function getCurrent() {
    let queryOptions = { active: true, lastFocusedWindow: true };
    // `tab` will either be a `tabs.Tab` instance or `undefined`.
    let [tab] = await chrome.tabs.query(queryOptions);
    return "tab";
}

async function Popup() {
    var url =" await getCurrent";

    return (
        <div>
            <a>tab: {url}</a>
            <h1>Hello, World!</h1>
            <p>This is a simple popup.</p>
        </div>
    );
}

render(<Popup/>, document.getElementById("react-target"));